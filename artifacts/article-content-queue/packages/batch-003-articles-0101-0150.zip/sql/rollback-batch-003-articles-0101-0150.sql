-- Roll back 50 generated articles (batch-003-articles-0101-0150)
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_520_ci;
SET collation_connection = 'utf8mb4_unicode_520_ci';
USE `navaraby_wp569`;

-- article: crop-130
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-130' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-116
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-116' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-128
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-128' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-125
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-125' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-126
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-126' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-123
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-123' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-120
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-120' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-122
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-122' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-124
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-124' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-134
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-134' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-137
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-137' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-141
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-141' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-138
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-138' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-132
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-132' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-139
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-139' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-133
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-133' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-143
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-143' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-136
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-136' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-131
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-131' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-146
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-146' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-145
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-145' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-144
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-144' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-154
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-154' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-147
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-147' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-150
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-150' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-148
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-148' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-152
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-152' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-151
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-151' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-158
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-158' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-153
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-153' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-165
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-165' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-163
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-163' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-164
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-164' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-162
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-162' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-161
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-161' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-160
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-160' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-169
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-169' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-156
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-156' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-157
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-157' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-166
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-166' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-168
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-168' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-178
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-178' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-181
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-181' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-176
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-176' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-183
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-183' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-177
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-177' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-172
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-172' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-180
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-180' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-170
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-170' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;


-- article: crop-171
START TRANSACTION; SET @post_id=(SELECT post_id FROM `ha_postmeta` WHERE meta_key='_navar_queue_item_id' AND meta_value='article-content-queue:crop-171' LIMIT 1); DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=@post_id AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=@post_id AND post_type='attachment'; DELETE FROM `ha_postmeta` WHERE post_id=@post_id; DELETE FROM `ha_term_relationships` WHERE object_id=@post_id; DELETE FROM `ha_posts` WHERE ID=@post_id; COMMIT;

