-- Rollback SQL for this 50-post package

-- rollback: 1020006001167-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='رامسر-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='رامسر-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='رامسر-مازندران-looleh-nakhi-tashoo' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='رامسر-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran'; COMMIT;


-- rollback: 1020007001006-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='اکند-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='اکند-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='اکند-مازندران-navar-tip-20cm' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='اکند-مازندران-navar-tip-20cm' AND post_type='mazandaran'; COMMIT;


-- rollback: 1020007001006-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='اکند-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='اکند-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='اکند-مازندران-looleh-nakhi-tashoo' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='اکند-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran'; COMMIT;


-- rollback: 1020007002170-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='کیاسر-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='کیاسر-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='کیاسر-مازندران-navar-tip-20cm' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='کیاسر-مازندران-navar-tip-20cm' AND post_type='mazandaran'; COMMIT;


-- rollback: 1020007002170-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='کیاسر-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='کیاسر-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='کیاسر-مازندران-looleh-nakhi-tashoo' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='کیاسر-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran'; COMMIT;


-- rollback: 1020008001170-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='آلاشت-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='آلاشت-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='آلاشت-مازندران-navar-tip-20cm' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='آلاشت-مازندران-navar-tip-20cm' AND post_type='mazandaran'; COMMIT;


-- rollback: 1020008001170-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='آلاشت-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='آلاشت-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='آلاشت-مازندران-looleh-nakhi-tashoo' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='آلاشت-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran'; COMMIT;


-- rollback: 1020008001172-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='زیرآب-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='زیرآب-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='زیرآب-مازندران-navar-tip-20cm' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='زیرآب-مازندران-navar-tip-20cm' AND post_type='mazandaran'; COMMIT;


-- rollback: 1020008001172-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='زیرآب-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='زیرآب-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='زیرآب-مازندران-looleh-nakhi-tashoo' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='زیرآب-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200027001173-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='شیرگاه-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='شیرگاه-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='شیرگاه-مازندران-navar-tip-20cm' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='شیرگاه-مازندران-navar-tip-20cm' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200027001173-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='شیرگاه-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='شیرگاه-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='شیرگاه-مازندران-looleh-nakhi-tashoo' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='شیرگاه-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200026001177-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='کیاکلا-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='کیاکلا-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='کیاکلا-مازندران-navar-tip-20cm' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='کیاکلا-مازندران-navar-tip-20cm' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200026001177-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='کیاکلا-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='کیاکلا-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='کیاکلا-مازندران-looleh-nakhi-tashoo' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='کیاکلا-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200024001165-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='کلارآباد-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='کلارآباد-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='کلارآباد-مازندران-navar-tip-20cm' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='کلارآباد-مازندران-navar-tip-20cm' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200024001165-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='کلارآباد-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='کلارآباد-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='کلارآباد-مازندران-looleh-nakhi-tashoo' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='کلارآباد-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200023001152-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='فریدونکنار-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='فریدونکنار-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='فریدونکنار-مازندران-navar-tip-20cm' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='فریدونکنار-مازندران-navar-tip-20cm' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200023001152-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='فریدونکنار-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='فریدونکنار-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='فریدونکنار-مازندران-looleh-nakhi-tashoo' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='فریدونکنار-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200010002747-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='ارطه-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='ارطه-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='ارطه-مازندران-navar-tip-20cm' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='ارطه-مازندران-navar-tip-20cm' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200010002747-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='ارطه-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='ارطه-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='ارطه-مازندران-looleh-nakhi-tashoo' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='ارطه-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200018002395-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='سرخرود-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='سرخرود-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='سرخرود-مازندران-navar-tip-20cm' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='سرخرود-مازندران-navar-tip-20cm' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200018002395-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='سرخرود-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='سرخرود-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='سرخرود-مازندران-looleh-nakhi-tashoo' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='سرخرود-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200025002305-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='سورک-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='سورک-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='سورک-مازندران-navar-tip-20cm' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='سورک-مازندران-navar-tip-20cm' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200025002305-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='سورک-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='سورک-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='سورک-مازندران-looleh-nakhi-tashoo' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='سورک-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200025002931-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='طبقده-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='طبقده-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='طبقده-مازندران-navar-tip-20cm' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='طبقده-مازندران-navar-tip-20cm' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200025002931-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='طبقده-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='طبقده-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='طبقده-مازندران-looleh-nakhi-tashoo' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='طبقده-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200014002648-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='ایزدشهر-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='ایزدشهر-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='ایزدشهر-مازندران-navar-tip-20cm' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='ایزدشهر-مازندران-navar-tip-20cm' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200014002648-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='ایزدشهر-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='ایزدشهر-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='ایزدشهر-مازندران-looleh-nakhi-tashoo' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='ایزدشهر-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200014002396-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='بلده-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='بلده-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='بلده-مازندران-navar-tip-20cm' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='بلده-مازندران-navar-tip-20cm' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200014002396-layflat
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='بلده-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='بلده-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='بلده-مازندران-looleh-nakhi-tashoo' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='بلده-مازندران-looleh-nakhi-tashoo' AND post_type='mazandaran'; COMMIT;


-- rollback: 10200014001193-tape20
START TRANSACTION; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='رویان-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND p.post_type='attachment'; DELETE FROM `ha_posts` WHERE post_parent=(SELECT ID FROM `ha_posts` WHERE post_name='رویان-مازندران-navar-tip-20cm' AND post_type='mazandaran' LIMIT 1) AND post_type='attachment'; DELETE pm FROM `ha_postmeta` pm JOIN `ha_posts` p ON p.ID=pm.post_id WHERE p.post_name='رویان-مازندران-navar-tip-20cm' AND p.post_type='mazandaran'; DELETE FROM `ha_posts` WHERE post_name='رویان-مازندران-navar-tip-20cm' AND post_type='mazandaran'; COMMIT;

